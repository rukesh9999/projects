package com.example.EmployeeRestControllerSPRINGDATAREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRestControllerSpringdatarestApplicationTests {

	@Test
	void contextLoads() {
	}

}
