package com.employee.EmployeeSpringBootHibernateAndJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSpringBootHibernateAndJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
