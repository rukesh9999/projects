package com.example.HRMS3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hrms3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
