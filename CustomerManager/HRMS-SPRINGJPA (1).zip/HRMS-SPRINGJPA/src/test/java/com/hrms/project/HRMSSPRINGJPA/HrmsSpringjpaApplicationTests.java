package com.hrms.project.HRMSSPRINGJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsSpringjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
