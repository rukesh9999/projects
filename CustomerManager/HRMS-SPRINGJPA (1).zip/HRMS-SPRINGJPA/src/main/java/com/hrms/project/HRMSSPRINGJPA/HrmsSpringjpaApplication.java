package com.hrms.project.HRMSSPRINGJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrmsSpringjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmsSpringjpaApplication.class, args);
	}

}
